
__BOT TESTE__

```rm -rf BOT > /dev/null 2>&1 && bash <(wget -qO- https://raw.githubusercontent.com/NT-GIT-HUB/Bot/main/inst-botteste)```


